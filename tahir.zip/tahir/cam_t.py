import cv2
import numpy as np
cap= cv2.VideoCapture(0)
while(True):
    ret, frame=cap.read()
    cv2.imshow('for Blind Vision',frame)
    if cv2.waitKey(5) & 0xFF == ord('q'):
        break

# When everything is done, cleanup
cap.release()
cv2.destroyAllWindows()
